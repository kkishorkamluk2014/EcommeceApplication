package com.kk.ecommerce.exception;
/**
 * @author Kishor.Kamlu
 *
 */
public class OrderDetailsNotAvailableException extends RuntimeException {
	
	OrderDetailsNotAvailableException(String errorMessage)
	{
		super(errorMessage);
	}

}
