package com.kk.ecommerce.service;

import java.util.List;


import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.kk.ecommerce.dto.ProductDto;
import com.kk.ecommerce.entity.Product;
/**
 * @author Kishor.Kamlu
 *
 */
public interface ProductService {

	public List<Product> getAllProductsByNames(String productname, String categoryname);

	public ProductDto addProducts(ProductDto productDto);
	public Product getProductById(Long product_Id);
	
}
