package com.kk.ecommerce.dto;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.kk.ecommerce.entity.Product;

/**
 * @author Kishor.Kamlu
 *
 */
public class OrderDto {
	
	private Long user_Id;
	private Long accountNo;
	private LocalDate date;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id")
	private Product product;
	//Getter
	//Setter
	public LocalDate getDate() {
		return date;
	}
	
	public Long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}

	public Long getUser_Id() {
		return user_Id;
	}
	public void setUser_Id(Long user_Id) {
		this.user_Id = user_Id;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	/*
	 * public List<ProductRequestDto> getProducts() { return products; } public void
	 * setProducts(List<ProductRequestDto> products) { this.products = products; }
	 */
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	
	
}
