package com.kk.ecommerce.dto;

import javax.validation.constraints.NotNull;

import com.kk.ecommerce.entity.Product;


/**
 * @author Kishor.Kamlu
 *
 */
public class ProductDto {
	
	private Product product;
	private String productname;
	private Double price;
	private int quantity;
	private String categoryname;
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getCategoryname() {
		return categoryname;
	}
	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}
	
		

}
