package com.kk.ecommerce.exception;
/**
 * @author Kishor.Kamlu
 *
 */
public class ProductNotFoundException extends RuntimeException{
	
	public ProductNotFoundException(String errorMessage) {
		super(errorMessage);
	}

}
