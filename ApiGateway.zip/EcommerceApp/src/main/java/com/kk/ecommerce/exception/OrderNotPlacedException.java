package com.kk.ecommerce.exception;

/**
 * @author Kishor.Kamlu
 *
 */
public class OrderNotPlacedException extends RuntimeException {
    
    public OrderNotPlacedException(String errorMessage){
        super(errorMessage);
    }
}
 