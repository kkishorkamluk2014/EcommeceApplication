package com.kk.ecommerce.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.kk.ecommerce.dto.OrderDto;
import com.kk.ecommerce.dto.OrderResponseDto;
/**
 * @author Kishor.Kamlu
 *
 */

@Service
public interface OrderService {

	String orderProduct(OrderDto orderDto);

	public List<OrderResponseDto> getOrderDetailsById(Long user_Id);

}
