package com.kk.ecommerce;


import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.kk.ecommerce.exception.OrderDetailsNotAvailableException;
import com.kk.ecommerce.exception.OrderNotPlacedException;
import com.kk.ecommerce.exception.ProductNotFoundException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

 


@RestControllerAdvice
public class GlobalException {
    
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(OrderNotPlacedException.class)
    public ResponseEntity<String> orderNotPlaced(OrderNotPlacedException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
    } 
    
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(ProductNotFoundException.class)
    public ResponseEntity<String> productNotFound(ProductNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
    } 
    
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(OrderDetailsNotAvailableException.class)
    public ResponseEntity<String> orderDetailsNotFound(OrderDetailsNotAvailableException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
    } 
}