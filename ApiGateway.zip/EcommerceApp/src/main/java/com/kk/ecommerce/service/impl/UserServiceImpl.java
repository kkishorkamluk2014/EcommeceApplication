package com.kk.ecommerce.service.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kk.ecommerce.dto.UserDto;
import com.kk.ecommerce.entity.User;
import com.kk.ecommerce.repository.UserRepository;
import com.kk.ecommerce.service.UserService;
/**
 * @author Kishor.Kamlu
 *
 */

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepository userRepository;
	@Override
	public UserDto saveUserDetails(UserDto userDto) {
		User user=new User(); 
		  BeanUtils.copyProperties(userDto, user);
		  userRepository.save(user); 
		  return userDto; 
	}

}
