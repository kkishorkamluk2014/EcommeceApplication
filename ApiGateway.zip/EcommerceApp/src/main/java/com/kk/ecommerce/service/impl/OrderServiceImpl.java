package com.kk.ecommerce.service.impl;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kk.ecommerce.dto.OrderDto;
import com.kk.ecommerce.dto.OrderResponseDto;
import com.kk.ecommerce.entity.Order_details;
import com.kk.ecommerce.entity.Product;
import com.kk.ecommerce.feignclient.BankClient;
import com.kk.ecommerce.repository.OrderRepository;
import com.kk.ecommerce.repository.ProductRepository;
import com.kk.ecommerce.repository.UserRepository;
import com.kk.ecommerce.service.OrderService;
/**
 * @author Kishor.Kamlu
 *
 */
@Service
public class OrderServiceImpl implements OrderService {
	
	private static final Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);
	
	@Autowired
	OrderRepository orderRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	ProductRepository productRepository;
	@Autowired
	ProductServiceImpl productServiceImpl;
	@Autowired
	BankClient bankClient;
	
	
	@Override
	public String orderProduct(OrderDto orderDto) {
		
		  Order_details orderDetails=new Order_details();
		  Product product=productServiceImpl.getProductById(orderDto.getProduct().getProduct_Id());
		  
		  logger.info("Product Object"+product);
		  orderDetails.setPrice(product.getPrice());
		  orderDetails.setQuantity(orderDto.getProduct().getQuantity());
		  orderDetails.setUser_Id(orderDto.getUser_Id());
		  orderDetails.setProduct(product);
		  orderDetails.setAccountNo(orderDto.getAccountNo()); 
		  double total=orderDetails.getPrice()*orderDetails.getQuantity();
		  orderDetails.setDate(orderDto.getDate()); 
		  orderDetails.setTotal_price(total);
		  String bankpayment=bankClient.paymentTransfer();
		  product.setQuantity(orderDetails.getProduct().getQuantity()-orderDto.getProduct().getQuantity());
		  BeanUtils.copyProperties(orderDetails, orderDto);
		  Order_details orderPlaced=orderRepository.save(orderDetails);
		
	
		  return "Order Placed successfully";
		  }
		  
	@Override
	public List<OrderResponseDto> getOrderDetailsById(Long user_Id) {
		
		List<Order_details> orderList=orderRepository.findByProduct(user_Id);
	
		return	orderList.stream().map(order -> getOrdersResponse(order)).collect(Collectors.toList());
	
	}
	private OrderResponseDto getOrdersResponse(Order_details orderDetails) {
		OrderResponseDto responseDto = new OrderResponseDto();
		BeanUtils.copyProperties(orderDetails, responseDto);
		responseDto.setProductName(productRepository.findProductNameByProductId(orderDetails.getProduct().getProduct_Id()));
		return responseDto;
	}
}


