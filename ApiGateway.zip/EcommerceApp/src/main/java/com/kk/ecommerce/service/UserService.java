package com.kk.ecommerce.service;

import com.kk.ecommerce.dto.UserDto;
/**
 * @author Kishor.Kamlu
 *
 */
public interface UserService {

	public UserDto saveUserDetails(UserDto userDto);
}
