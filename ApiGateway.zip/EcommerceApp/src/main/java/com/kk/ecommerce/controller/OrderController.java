package com.kk.ecommerce.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kk.ecommerce.dto.OrderDto;
import com.kk.ecommerce.dto.OrderResponseDto;
import com.kk.ecommerce.exception.OrderDetailsNotAvailableException;
import com.kk.ecommerce.service.OrderService;
import com.kk.ecommerce.service.impl.ProductServiceImpl;


/**
 * @author Kishor.Kamlu
 *
 */
@RestController
@RequestMapping("/orders")
public class OrderController {
	Logger logger=LoggerFactory.getLogger(OrderController.class);
	@Autowired
	OrderService orderService;
	
	@Autowired
	ProductServiceImpl productServiceImp;
	
	/**
	 * @param user_Id
	 * @return getOrderDetailsById
	 */
	@GetMapping("/{user_Id}")
	public List<OrderResponseDto> getOrderDetailsById(@PathVariable Long user_Id) throws OrderDetailsNotAvailableException
	{
		
		return orderService.getOrderDetailsById(user_Id);
	}
	/**
	 * @param Order_Details
	 * @return OrderProduct
	 */
	@PostMapping
	public ResponseEntity<?> orderProduct(@RequestBody OrderDto orderDto) {
		
		String orderDtos= orderService.orderProduct(orderDto);
		if(orderDtos!=null) {
			return new ResponseEntity<String>(orderDtos,HttpStatus.CREATED );
		}else {
			return new ResponseEntity<String>("Ordering failed",HttpStatus.NOT_FOUND );		
		}
	}
		
		
	}

